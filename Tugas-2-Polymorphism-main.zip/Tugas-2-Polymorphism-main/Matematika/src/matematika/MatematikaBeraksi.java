/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matematika;

/**
 *
 * @author dimas
 */
public class MatematikaBeraksi {
    public static void main(String[] args) {
    Matematika hasil  = new Matematika();
    hasil.pertambahan(4, 4);
    hasil.perkurangan(5, 2);
    hasil.perkalian(6, 3);
    hasil.pembagian(8, 2);
    }
}
